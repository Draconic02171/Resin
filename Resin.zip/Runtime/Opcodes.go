package runtime

import (
	"errors"
	"fmt"
)

type OpcodeType uint

const ( //Resin Arch
	_Invalid OpcodeType = iota
	Op_Push
	Op_Pop
	Op_Swap
	Op_Dup
	Op_Load
	Op_Store

	Op_Add
	Op_Sub
	Op_Mul
	Op_Div
	Op_Mod

	Op_Equal
	Op_More
	Op_Less
	Op_MoreOrEqual
	Op_LessOrEqual

	Op_Jump
	Op_JumpIfTrue
	Op_JumpIfFalse

	Op_Function
	Op_Call
	Op_Return

	Op_Read
	Op_Print
	Op_Peek
	Op_Halt //not sure what to do with this
)

func ( vm *VM ) push(operand []Value) (error) {

	//write an error handling for insPointer out of bound
	errMsg := "Error: 'push'"
	if len(operand) == 0 {
		return fmt.Errorf("%s \r\nno argument passed (operand count: %d)\r\n" , errMsg , len(operand))
	}

	err := vm.incrementPointer(1)
	if err != nil { return errors.Join(errors.New(errMsg) , err) }

	vm.stack[vm.stackPointer] = operand[0]
	
	return nil

}
func ( vm *VM ) pop() (error , Value) {

	//write an error handling for insPointer out of bound
	errMsg := "Error: 'pop'"

	ReturnValue := vm.stack[vm.stackPointer]
	vm.stack[vm.stackPointer] = Value{}
	err := vm.decrementPointer(1)

	if err != nil {
		return errors.Join(errors.New(errMsg) , err), Value{}
	}
	
	return nil, ReturnValue

}
func ( vm *VM ) swap() (error) {
	errMsg := "Error: 'swap'"

	TopValue := vm.stack[vm.stackPointer]
	
	err := vm.decrementPointer(1)
	if err != nil {return errors.Join(errors.New(errMsg) , err)}
	
	BottomValue := vm.stack[vm.stackPointer]
	vm.stack[vm.stackPointer] = TopValue
	
	err = vm.incrementPointer(1)
	if err != nil {return errors.Join(errors.New(errMsg) , err)}

	vm.stack[vm.stackPointer] = BottomValue
	
	return nil
} 
func ( vm *VM ) dup() (error) {

	//write an error handling for insPointer out of bound
	errMsg := "Error: 'dup'"
	CopiedValue := vm.stack[vm.stackPointer]
	
	err := vm.incrementPointer(1)
	if err != nil { return errors.Join(errors.New(errMsg) , err) }

	vm.stack[vm.stackPointer] = CopiedValue
	
	return nil

}
func ( vm *VM ) load(operand []Value) (error) { //not test yet!
	
	errMsg := "Error: 'load'"
	if len(operand) == 0 {
		return fmt.Errorf(
			"%s \r\nno argument passed (operand count: %d)" , 
			errMsg , 
			len(operand),
		)
	}
	if operand[0]._type != _string_ {
		return fmt.Errorf(
			"%s \r\nrequire string type argument" ,
			errMsg,
		)
	}

	VarName := operand[0]._value.(string)
	LoadedValue, success := vm.memory[VarName].(Value)

	if !success {
		return fmt.Errorf(
			"%s \r\nTrying to access to a non-declared variable: %s" , 
			errMsg , 
			VarName,
		) 
	}

	err := vm.push([]Value{LoadedValue})
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	return nil

}
func (vm *VM) store(operand []Value) (error) { //not test yet!

	errMsg := "Error: 'store'"
	if len(operand) <= 0 {
		return fmt.Errorf("%s \r\nno argument passed (operand count: %d)" , errMsg , len(operand))
	} 
	if operand[0]._type != _string_ {
		return fmt.Errorf("%s \r\nrequire string type argument" , errMsg)
	}

	VarName := operand[0]._value.(string)
	StoredValue := vm.stack[vm.stackPointer]

	if StoredValue._type == _null_ {
		return fmt.Errorf("%s \r\ntrying to store a null value" , errMsg)
	}

	vm.memory[VarName] = StoredValue

	return nil

}

func ( vm *VM ) add() (error) {

	//write an error handling for insPointer out of bound
	errMsg := "Error: 'add'"

	err, RightHand := vm.pop()
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	err, Lefthand := vm.pop()
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	{ // check for value type
		if RightHand.GetType() != _number_ { 
			return errors.Join(
				errors.New(errMsg) , 
				errors.New("right hand side is not a number"),
			) 
		}
		if Lefthand.GetType() != _number_ { 
			return errors.Join(
				errors.New(errMsg) , 
				errors.New("right hand side is not a number"),
			) 
		}
	}

	left 	:= Lefthand.GetValue().(Number)
	right 	:= RightHand.GetValue().(Number)
	
	ReturnValue := []Value{{ _type: _number_, _value: left + right }}

	err = vm.push(ReturnValue)
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	return nil
}
func ( vm *VM ) sub() (error) {

	//write an error handling for insPointer out of bound
	errMsg := "Error: 'sub'"

	err, RightHand := vm.pop()
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	err, Lefthand := vm.pop()
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	{ // check for value type
		if RightHand.GetType() != _number_ { 
			return errors.Join(
				errors.New(errMsg) , 
				errors.New("right hand side is not a number"),
			) 
		}
		if Lefthand.GetType() != _number_ { 
			return errors.Join(
				errors.New(errMsg) , 
				errors.New("right hand side is not a number"),
			) 
		}
	}

	left 	:= Lefthand.GetValue().(Number)
	right 	:= RightHand.GetValue().(Number)
	
	ReturnValue := []Value{{ _type: _number_, _value: left - right }}

	err = vm.push(ReturnValue)
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	return nil
}
func ( vm *VM ) mul() (error) {

	//write an error handling for insPointer out of bound
	errMsg := "Error: 'mul'"

	err, RightHand := vm.pop()
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	err, Lefthand := vm.pop()
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	{ // check for value type
		if RightHand.GetType() != _number_ { 
			return errors.Join(
				errors.New(errMsg) , 
				errors.New("right hand side is not a number"),
			) 
		}
		if Lefthand.GetType() != _number_ { 
			return errors.Join(
				errors.New(errMsg) , 
				errors.New("right hand side is not a number"),
			) 
		}
	}

	left 	:= Lefthand.GetValue().(Number)
	right 	:= RightHand.GetValue().(Number)
	
	ReturnValue := []Value{{ _type: _number_, _value: left * right }}

	err = vm.push(ReturnValue)
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	return nil
}
func ( vm *VM ) div() (error) {

	//write an error handling for insPointer out of bound
	errMsg := "Error: 'div'"

	err, RightHand := vm.pop()
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	err, Lefthand := vm.pop()
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	{ // check for value type
		if RightHand.GetType() != _number_ { 
			return errors.Join(
				errors.New(errMsg) , 
				errors.New("right hand side is not a number"),
			) 
		}
		if Lefthand.GetType() != _number_ { 
			return errors.Join(
				errors.New(errMsg) , 
				errors.New("right hand side is not a number"),
			) 
		}
	}

	left 	:= Lefthand.GetValue().(Number)
	right 	:= RightHand.GetValue().(Number)
	
	ReturnValue := []Value{{ _type: _number_, _value: left / right }}

	err = vm.push(ReturnValue)
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	return nil
}
func ( vm *VM ) mod() (error) {

	//write an error handling for insPointer out of bound
	errMsg := "Error: 'mod'"

	err, RightHand := vm.pop()
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	err, Lefthand := vm.pop()
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	{ // check for value type
		if RightHand.GetType() != _number_ { 
			return errors.Join(
				errors.New(errMsg) , 
				errors.New("right hand side is not a number"),
			) 
		}
		if Lefthand.GetType() != _number_ { 
			return errors.Join(
				errors.New(errMsg) , 
				errors.New("right hand side is not a number"),
			) 
		}
	}

	// convert back to int for modulo
	left 	:= int(Lefthand.GetValue().(Number))
	right 	:= int(RightHand.GetValue().(Number))
	
	ReturnValue := []Value{{ _type: _number_, _value: Number(left % right) }}

	err = vm.push(ReturnValue)
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	return nil
}

func ( vm *VM ) equal() (error) {

	//write an error handling for insPointer out of bound
	errMsg := "Error: 'equal'"

	err, RightHand := vm.pop()
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	err, Lefthand := vm.pop()
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	{ // check for value type
		if RightHand.GetType() != _number_ { 
			return errors.Join(
				errors.New(errMsg) , 
				errors.New("right hand side is not a number"),
			) 
		}
		if Lefthand.GetType() != _number_ { 
			return errors.Join(
				errors.New(errMsg) , 
				errors.New("right hand side is not a number"),
			) 
		}
	}

	left 	:= Lefthand.GetValue().(Number)
	right 	:= RightHand.GetValue().(Number)
	
	ReturnValue := []Value{{ _type: _bool_, _value: bool(left == right) }}

	err = vm.push(ReturnValue)
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	return nil
}
func ( vm *VM ) more() (error) {

	//write an error handling for insPointer out of bound
	errMsg := "Error: 'more'"

	err, RightHand := vm.pop()
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	err, Lefthand := vm.pop()
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	{ // check for value type
		if RightHand.GetType() != _number_ { 
			return errors.Join(
				errors.New(errMsg) , 
				errors.New("right hand side is not a number"),
			) 
		}
		if Lefthand.GetType() != _number_ { 
			return errors.Join(
				errors.New(errMsg) , 
				errors.New("right hand side is not a number"),
			) 
		}
	}

	left 	:= Lefthand.GetValue().(Number)
	right 	:= RightHand.GetValue().(Number)
	
	ReturnValue := []Value{{ _type: _bool_, _value: bool(left > right) }}

	err = vm.push(ReturnValue)
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	return nil
}
func ( vm *VM ) less() (error) {

	//write an error handling for insPointer out of bound
	errMsg := "Error: 'less'"

	err, RightHand := vm.pop()
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	err, Lefthand := vm.pop()
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	{ // check for value type
		if RightHand.GetType() != _number_ { 
			return errors.Join(
				errors.New(errMsg) , 
				errors.New("right hand side is not a number"),
			) 
		}
		if Lefthand.GetType() != _number_ { 
			return errors.Join(
				errors.New(errMsg) , 
				errors.New("right hand side is not a number"),
			) 
		}
	}

	left 	:= Lefthand.GetValue().(Number)
	right 	:= RightHand.GetValue().(Number)
	
	ReturnValue := []Value{{ _type: _bool_, _value: bool(left < right) }}

	err = vm.push(ReturnValue)
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	return nil
}
func ( vm *VM ) moreOrEqual() (error) {

	//write an error handling for insPointer out of bound
	errMsg := "Error: 'moreOrEqual'"

	err, RightHand := vm.pop()
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	err, Lefthand := vm.pop()
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	{ // check for value type
		if RightHand.GetType() != _number_ { 
			return errors.Join(
				errors.New(errMsg) , 
				errors.New("right hand side is not a number"),
			) 
		}
		if Lefthand.GetType() != _number_ { 
			return errors.Join(
				errors.New(errMsg) , 
				errors.New("right hand side is not a number"),
			) 
		}
	}

	left 	:= Lefthand.GetValue().(Number)
	right 	:= RightHand.GetValue().(Number)
	
	ReturnValue := []Value{{ _type: _bool_, _value: bool(left >= right) }}

	err = vm.push(ReturnValue)
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	return nil
}
func ( vm *VM ) lessOrEqual() (error) {

	//write an error handling for insPointer out of bound
	errMsg := "Error: 'lessOrEqual'"

	err, RightHand := vm.pop()
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	err, Lefthand := vm.pop()
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	{ // check for value type
		if RightHand.GetType() != _number_ { 
			return errors.Join(
				errors.New(errMsg) , 
				errors.New("right hand side is not a number"),
			) 
		}
		if Lefthand.GetType() != _number_ { 
			return errors.Join(
				errors.New(errMsg) , 
				errors.New("right hand side is not a number"),
			) 
		}
	}

	left 	:= Lefthand.GetValue().(Number)
	right 	:= RightHand.GetValue().(Number)
	
	ReturnValue := []Value{{ _type: _bool_, _value: bool(left <= right) }}

	err = vm.push(ReturnValue)
	if err != nil {
		return errors.Join(errors.New(errMsg) , err)
	}

	return nil
}

func (vm *VM) peek() (error) {

	fmt.Print(vm.stack[vm.stackPointer].GetValue())
	return nil
}

