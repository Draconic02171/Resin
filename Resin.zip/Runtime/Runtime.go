package runtime

import (
	"errors"
	"fmt"
)

const MAXSTACK uint = 2048

type VM struct {
	running				bool //serves nothing for now
	stackPointer 		uint
	stackSize			uint
	stack        		[MAXSTACK]Value

	instructionPointer 	uint
	programSize			uint
	program 			[]Instruction

	memory				map[string]any
}

// ----------------------Constructor---------------------- //
func InitRuntime() *VM { 

	return &VM{ 
		
		running: false,
		stackPointer: 0, 
		stackSize: MAXSTACK,
		stack: [MAXSTACK]Value{},    	
		
		instructionPointer: 0,
		programSize: 0,
		program: nil,
	
		memory: make(map[string]any),

	}

}

// ----------------------  Private  ---------------------- //
func ( vm *VM )incrementPointer( steps uint ) error {

	if (vm.stackPointer + steps) >= vm.stackSize {
		return fmt.Errorf("Cannot increment stack pointer (stack overflow)\r\n") 
	}

	vm.stackPointer += steps
	return nil
	
}

func ( vm *VM )decrementPointer( steps uint ) error {

	if vm.stackPointer < steps { 
		return fmt.Errorf("Cannot decrement stack pointer (stack underflow)\r\n") 
	}

	vm.stackPointer -= steps
	return nil

}

func ( vm *VM ) setInsPointer( where uint ) error {

	if len(vm.program) < int(where) {
		return fmt.Errorf(
			"InstructionPointer out of bound! (program size: %d, tried to jump to: %d)\r\n",
			len(vm.program) , 
			int(where),
		)
	}

	vm.instructionPointer = where
	return nil
	
}

func ( vm *VM ) getInsPointer() uint { return vm.instructionPointer }

func ( vm *VM ) getCurrentInst() *Instruction { return &vm.program[vm.instructionPointer] }

// --------------------Getter / Setter-------------------- // 
func ( vm *VM ) IsRunning() bool { return vm.running } // not in use for now


// ----------------------  Public  ---------------------- //
func ( vm *VM ) LoadProgram(program []Instruction) error {

	if (program == nil) 	{ return fmt.Errorf("Cannot load the program (nothing passed )") }
	if (len(program) == 0) 	{ return fmt.Errorf("Theres no program to load (program size = 0)")}

	vm.program 		= program
	vm.programSize 	= uint(len(program))
	
	return nil

}

//run the loaded program
func ( vm *VM ) Run() error {

	var Msg any = nil // for catching an opcode error or warning
	RuntimeErrorMsg := "Runtime Error!"
	vm.running = true

	for vm.running {

		if vm.instructionPointer >= vm.programSize {
			vm.running = false
			return errors.Join(
				errors.New(RuntimeErrorMsg),
				fmt.Errorf("Insturction Pointer exceeds the program size for some reason\r\n"),
			)
		}

		CurrentIns := vm.program[vm.instructionPointer]

		

		switch CurrentIns.opcode {
		case Op_Push 			: Msg 	= vm.push(CurrentIns.GetOperand())
		case Op_Pop 			: Msg,_ = vm.pop()
		case Op_Swap 			: Msg 	= vm.swap()
		case Op_Dup 			: Msg 	= vm.dup()
		case Op_Load 			: Msg 	= vm.load(CurrentIns.GetOperand())
		case Op_Store 			: Msg 	= vm.store(CurrentIns.GetOperand())

		case Op_Add 			: Msg 	= vm.add()
		case Op_Sub 			: Msg 	= vm.sub()
		case Op_Mul 			: Msg 	= vm.mul()
		case Op_Div 			: Msg 	= vm.div()
		case Op_Mod  			: Msg 	= vm.mod()

		case Op_Equal 			: Msg 	= vm.equal()
		case Op_More 			: Msg 	= vm.more()
		case Op_Less 			: Msg 	= vm.less()
		case Op_MoreOrEqual 	: Msg 	= vm.moreOrEqual()
		case Op_LessOrEqual 	: Msg 	= vm.lessOrEqual()

		case Op_Jump 			: //Msg 	= 
		case Op_JumpIfTrue 		:
		case Op_JumpIfFalse 	:
 
		case Op_Function 		:
		case Op_Call 			:
		case Op_Return 			:
 
		case Op_Read 			:
		case Op_Print 			: 
		case Op_Peek 			: Msg 	= vm.peek()
		case Op_Halt 			: vm.running = false
		}

		if Msg != nil { fmt.Printf("%v" , Msg) }
		vm.setInsPointer(vm.getInsPointer() + 1)
	}

	return nil
}