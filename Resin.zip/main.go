package main

import (
	Runtime "Resin/Runtime"
)

func main() {

	Program := []Runtime.Instruction{
		Runtime.Code(Runtime.Op_Push , []Runtime.Value{Runtime.NewValue(5)}, 0),
		// Runtime.Code(Runtime.Op_Push , []Runtime.Value{Runtime.NewValue(5)}, 1),
		// Runtime.Code(Runtime.Op_Push , []Runtime.Value{Runtime.NewValue(10)}, 2),
		Runtime.Code(Runtime.Op_Add , []Runtime.Value{}, 3),
		Runtime.Code(Runtime.Op_Swap , []Runtime.Value{}, 4),
		Runtime.Code(Runtime.Op_Sub , []Runtime.Value{}, 5),
		Runtime.Code(Runtime.Op_Peek , []Runtime.Value{}, 6),
	}

	vm := Runtime.InitRuntime()
	vm.LoadProgram(Program)
	vm.Run()
	vm.DumpCore()
}